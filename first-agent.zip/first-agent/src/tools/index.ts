import { getCurrentTimeTool } from './getCurrentTime';

export const tools = [
  getCurrentTimeTool,
  // Add other tools here
];
